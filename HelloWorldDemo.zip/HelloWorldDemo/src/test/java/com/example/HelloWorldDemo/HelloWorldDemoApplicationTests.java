package com.example.HelloWorldDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloWorldDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
